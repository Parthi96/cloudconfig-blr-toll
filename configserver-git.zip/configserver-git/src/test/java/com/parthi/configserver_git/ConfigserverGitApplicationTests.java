package com.parthi.configserver_git;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigserverGitApplicationTests {

	@Test
	void contextLoads() {
	}

}
